import SwiftUI

struct home_view: View {

    @EnvironmentObject var teamStore: TeamStore
    @StateObject private var teamsViewModel = ViewModel()

    @EnvironmentObject var playerStore: PlayerStore

    @State private var showTeams = false
    @State private var showPlayers = false

    private var teams: [Team] { teamsViewModel.teams }

    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemBackground).ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 16) {

                        Text("Home")
                            .font(.largeTitle).bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 20)
                            .foregroundColor(Color(.label))

                        sectionTitle("Players")

                        if playerStore.players.isEmpty {
                            Text("No players created")
                                .foregroundColor(Color(.secondaryLabel))
                                .padding(.top, 6)
                                .frame(maxWidth: .infinity, alignment: .center)
                                .padding(.horizontal, 20)
                            
                            Button(action: { showPlayers = true }) {
                                Text("Create Player")
                                    .font(.body)
                                    .foregroundColor(Color(.systemBlue)
                            )}
                        } else {
                            ForEach(playerStore.players, id: \.id) { player in
                                PlayerHomeCard(player: player)
                                    .padding(.horizontal, 20)
                            }
                        }

                        Divider()
                            .padding(.horizontal, 20)
                            .padding(.top, 8)

                        sectionTitle("Teams")

                        if teamStore.teamIDs.isEmpty {
                            VStack(spacing: 10) {
                                Text("No teams selected")
                                    .foregroundColor(Color(.secondaryLabel))
                                    .padding(.top, 10)

                                Button(action: { showTeams = true }) {
                                    Text("Add teams")
                                        .font(.body)
                                        .foregroundColor(Color(.systemBlue))
                                }
                                .padding(.top, 6)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.horizontal, 20)
                        } else {
                            ForEach(teamStore.teamIDs, id: \.self) { id in
                                if let team = teams.first(where: { $0.id == id }) {
                                    TeamHomeCard(team: team)
                                        .padding(.horizontal, 20)
                                }
                            }
                        }
                    }
                    .padding(.vertical, 24)
                }
            }
            .navigationBarTitle("", displayMode: .inline)
            .onAppear {
                if teams.isEmpty {
                    teamsViewModel.fetchAllTeams()
                }
            }
            .sheet(isPresented: $showTeams) {
                AddingTeamsView()
            }
            .sheet(isPresented: $showPlayers) {
                AddingPlayersView(isPresented: $showPlayers)
            }
        }
    }
    
    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.title3).bold()
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 20)
            .foregroundColor(Color(.label))
            .padding(.top, 6)
    }
}

