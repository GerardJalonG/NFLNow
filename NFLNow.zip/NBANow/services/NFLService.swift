import Foundation

struct NFLService {

    static func fetchTeams(
        completion: @escaping (Result<[Team], APIError>) -> Void
    ) {
        let urlString = "\(APIConstants.baseURL)/teams"
        
        guard let url = URL(string: "\(urlString)") else {
            completion(.failure(.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                completion(.failure(.urlSessionError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let data = data else {
                completion(.failure(.invalidResponse))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(Root.self, from: data)

                var teams: [Team] = []
                for sport in decoded.sports {
                    for league in sport.leagues {
                        for teamContainer in league.teams {
                            teams.append(teamContainer.team)
                        }
                    }
                }
                completion(.success(teams))
            } catch {
                completion(.failure(.decodingFailed(error)))
            }

        }.resume()
    }
    
    static func fetchTeamDetails(
        teamId: String,
        completion: @escaping (Result<Team, APIError>) -> Void
    ) {
        let urlString = "\(APIConstants.baseURL)/teams/\(teamId)"
        
        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                completion(.failure(.urlSessionError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let data = data else {
                completion(.failure(.invalidResponse))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(TeamDetail.self, from: data)
                completion(.success(decoded.team))
            } catch {
                print("DECODE ERROR:", error)
                completion(.failure(.decodingFailed(error)))
            }

        }.resume()
    }
    
    static func fetchGameSummary(
        eventId: String,
        completion: @escaping (Result<GameSummaryData, APIError>) -> Void
    ) {

        let urlString = "\(APIConstants.baseURL)/summary?event=\(eventId)"

        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                completion(.failure(.urlSessionError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let data = data else {
                completion(.failure(.invalidResponse))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(GameSummaryData.self, from: data)
                completion(.success(decoded))
            } catch {
                print("DECODE ERROR (SUMMARY):", error)
                completion(.failure(.decodingFailed(error)))
            }

        }.resume()
    }

    
    static func fetchTeamRosterGroups(
        teamId: String,
        completion: @escaping (Result<Roster, APIError>) -> Void
    ) {
        let urlString = "\(APIConstants.baseURL)/teams/\(teamId)/roster"

        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                completion(.failure(.urlSessionError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let data = data else {
                completion(.failure(.invalidResponse))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(Roster.self, from: data)
                completion(.success(decoded))
            } catch {
                print("DECODE ERROR (ROSTER):", error)
                completion(.failure(.decodingFailed(error)))
            }

        }.resume()
    }
    
    static func fetchGameScoreboard(
        completion: @escaping (Result<ScoreBoardResponse, APIError>) -> Void
    ){
        let urlString = "\(APIConstants.baseURL)/scoreboard"

        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(.urlSessionError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let data = data else {
                completion(.failure(.invalidResponse))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(ScoreBoardResponse.self, from: data)
                completion(.success(decoded))
            } catch {
                print("DECODE ERROR (SCOREBOARD):", error)
                completion(.failure(.decodingFailed(error)))
            }
        }.resume()
    }
    
    static func fetchSummary(
        eventId: String,
        completion: @escaping (Result<GameSummaryData, APIError>) -> Void
    ) {
        let urlString = "\(APIConstants.baseURL)/summary?event=\(eventId)"

        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                completion(.failure(.urlSessionError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode),
                  let data = data else {
                completion(.failure(.invalidResponse))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(GameSummaryData.self, from: data)
                completion(.success(decoded))
            } catch {
                print("DECODE ERROR (SUMMARY):", error)
                completion(.failure(.decodingFailed(error)))
            }

        }.resume()
    }

}
